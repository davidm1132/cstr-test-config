﻿configuration CreateDcUsersOnly 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

		[Parameter(Mandatory)]
        [String]$ClusterAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$ClusterAdminPassword,

        [Parameter(Mandatory)]
        [String]$SqlServerServiceAccount,

        [Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServicePassword,

        [Parameter(Mandatory)]
        [String]$SqlAgentServiceAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SqlAgentServicePassword,

        [Parameter(Mandatory)]
        [String]$SqlServerAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SqlServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$WebServiceAppPoolAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$WebServiceAppPoolPassword,

        [Parameter(Mandatory)]
        [String]$WebServerAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$WebServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$AppServerServiceAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AppServerServicePassword,

        [Parameter(Mandatory)]
        [String]$AppServerAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AppServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$KioskOpsAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$KioskOpsAdminPassword,

        [Parameter(Mandatory)]
        [String]$KioskOpsReadOnlyAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$KioskOpsReadOnlyPassword,

        [Int]$RetryCount=10,
        [Int]$RetryIntervalSec=10
    ) 
    
	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName @{ModuleName="xActiveDirectory";ModuleVersion="2.11.0.0"}, PSDesiredStateConfiguration;
    [System.Management.Automation.PSCredential ]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password);


    Node localhost
    {
		# Create a Cluster Administration user account:
		xADUser ClusterAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $ClusterAdminAccount
			UserPrincipalName = $ClusterAdminAccount + "@" + $DomainName
			Password = $ClusterAdminPassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "Cluster Administrator account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a SQL Server Windows Service user account:
		xADUser SqlServerServiceUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $SqlServerServiceAccount
			UserPrincipalName = $SqlServerServiceAccount + "@" + $DomainName
			Password = $SqlServerServicePassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "SQL Server Service account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a SQL Agent Windows Service user account:
		xADUser SqlAgentServiceUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $SqlAgentServiceAccount
			UserPrincipalName = $SqlAgentServiceAccount + "@" + $DomainName
			Password = $SqlAgentServicePassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "SQL Agent Service account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a SQL Server Administrative user account:
		xADUser SqlServerAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $SqlServerAdminAccount
			UserPrincipalName = $SqlServerAdminAccount + "@" + $DomainName
			Password = $SqlServerAdminPassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "SQL Server Admin account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a Web Service App Pool account:
		xADUser WebServiceAppPoolUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $WebServiceAppPoolAccount
			UserPrincipalName = $WebServiceAppPoolAccount + "@" + $DomainName
			Password = $WebServiceAppPoolPassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "Web Service App Pool account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a Web Server Admin account:
		xADUser WebServerAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $WebServerAdminAccount
			UserPrincipalName = $WebServerAdminAccount + "@" + $DomainName
			Password = $WebServerAdminPassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "Web Server Admin account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create an Application Service account:
		xADUser AppServerServiceUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $AppServerServiceAccount
			UserPrincipalName = $AppServerServiceAccount + "@" + $DomainName
			Password = $AppServerServicePassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "Application Server service account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a App Server Admin account:
		xADUser AppServerAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $AppServerAdminAccount
			UserPrincipalName = $AppServerAdminAccount + "@" + $DomainName
			Password = $AppServerAdminPassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "Application Server Admin account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a KioskOps Administrative account:
		xADUser KioskOpsAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $KioskOpsAdminAccount
			UserPrincipalName = $KioskOpsAdminAccount + "@" + $DomainName
			Password = $KioskOpsAdminPassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "KioskOps Administrative account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a KioskOps Read Only account:
		xADUser KioskOpsReadOnlyUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $KioskOpsReadOnlyAccount
			UserPrincipalName = $KioskOpsReadOnlyAccount + "@" + $DomainName
			Password = $KioskOpsReadOnlyPassword
			Ensure = "Present"
			PasswordNeverExpires = $True
			DisplayName = "KioskOps Read Only account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create an AD Group for KioskOps EXEC:
# 		xADGroup KioskOpsDbExecGroup
# 		{
# 			GroupName = "Domain Admins"
# 			Ensure = "Present"
# 			Credential = $DomainCredentials
# 			MembersToInclude = "$DomainName\$ClusterAdminAccount"
# 		}

		# Create an AD Group for KioskOps Administrator:
# 		xADGroup KioskOpsDbAdminGroup
# 		{
#           DependsOn = "[xADDomain]DomainServiceFileSetup"
# 			GroupName = "KioskOpsDbAdmin"
# 			Path = "CN=KioskOpsAdmin,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
# 			Ensure = "Present"
# 			Description = "KioskOps database Administrators"
# 			DisplayName = "KioskOps DB Admins"
# 			Credential = $DomainCredentials
# 			MembersToInclude = "$DomainName\$KioskOpsAdminAccount"
# 		}

		# Create an AD Group for KioskOps ReadOnly:
# 		xADGroup KioskOpsDbReadOnlyGroup
# 		{
#           DependsOn = "[xADDomain]DomainServiceFileSetup"
# 			GroupName = "KioskOpsDbReadOnly"
# 			Path = "CN=KioskOpsReadOnly,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
# 			Ensure = "Present"
# 			Description = "KioskOps database Read Only"
# 			DisplayName = "KioskOps DB Read Only"
# 			Credential = $DomainCredentials
# 			MembersToInclude = "$DomainName\$KioskOpsReadOnlyAccount"
# 		}

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
   }
}
 