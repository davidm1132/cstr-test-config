﻿configuration CreatePrimaryDcForest 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerServiceAccount,

        [Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServicePassword,

        [Parameter(Mandatory)]
        [String]$SqlAgentServiceAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SqlAgentServicePassword,

        [Parameter(Mandatory)]
        [String]$SqlServerAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SqlServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$WebServiceAppPoolAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$WebServiceAppPoolPassword,

        [Parameter(Mandatory)]
        [String]$WebServerAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$WebServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$AppServerServiceAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AppServerServicePassword,

        [Parameter(Mandatory)]
        [String]$AppServerAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AppServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$KioskOpsAdminAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$KioskOpsAdminPassword,

        [Parameter(Mandatory)]
        [String]$KioskOpsReadOnlyAccount,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$KioskOpsReadOnlyPassword,

        [Int]$RetryCount=10,
        [Int]$RetryIntervalSec=10
    ) 
    
	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, cDisk, PSDesiredStateConfiguration;
    [System.Management.Automation.PSCredential ]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password);

    $Interface = Get-NetAdapter | Where Name -Like "Ethernet*" | Select-Object -First 1;
    $InterfaceAlias = $($Interface.Name);

    Node localhost
    {
		# Add DNS Windows Feature:
		Script EnableDnsDiagnostics
		{
      	    SetScript =  { 
				Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false}
			DependsOn = "[WindowsFeature]DNS"
        }
	
		WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"		
        }

		WindowsFeature DnsTools
		{
			Ensure = "Present"
            Name = "RSAT-DNS-Server"
			DependsOn = "[WindowsFeature]DNS"
		}

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
			DependsOn = "[WindowsFeature]DNS"
        }

		# Make sure Disk #2 is available:
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

		#Install Active Directory Domain Services:
        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
			DependsOn= "[cDiskNoRestart]ADDataDisk"
        }  

		#Install AD Administration center:
		WindowsFeature ADAdminCenter 
        { 
            Ensure = "Present" 
            Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
        }
		
		#Install AD tools:
		WindowsFeature ADDSTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
        }  

		# Configure the Domain Service files:
        xADDomain DomainServiceFileSetup 
        {
            DependsOn = "[WindowsFeature]ADDSInstall"
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCredentials
            SafemodeAdministratorPassword = $DomainCredentials
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
        }

		# Create a SQL Server Windows Service user account:
		xADUser SqlServerServiceUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $SqlServerServiceAccount
			Password = $SqlServerServicePassword
			Ensure = "Present"
			DisplayName = "SQL Server Service account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a SQL Agent Windows Service user account:
		xADUser SqlAgentServiceUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $SqlAgentServiceAccount
			Password = $SqlAgentServicePassword
			Ensure = "Present"
			DisplayName = "SQL Agent Service account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a SQL Server Administrative user account:
		xADUser SqlServerAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $SqlServerAdminAccount
			Password = $SqlServerAdminPassword
			Ensure = "Present"
			DisplayName = "SQL Server Admin account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a Web Service App Pool account:
		xADUser WebServiceAppPoolUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $WebServiceAppPoolAccount
			Password = $WebServiceAppPoolPassword
			Ensure = "Present"
			DisplayName = "Web Service App Pool account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a Web Server Admin account:
		xADUser WebServerAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $WebServerAdminAccount
			Password = $WebServerAdminPassword
			Ensure = "Present"
			DisplayName = "Web Server Admin account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create an Application Service account:
		xADUser AppServerServiceUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $AppServerServiceAccount
			Password = $AppServerServicePassword
			Ensure = "Present"
			DisplayName = "Application Server service account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a App Server Admin account:
		xADUser AppServerAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $AppServerAdminAccount
			Password = $AppServerAdminPassword
			Ensure = "Present"
			DisplayName = "Application Server Admin account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a KioskOps Administrative account:
		xADUser KioskOpsAdminUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $KioskOpsAdminAccount
			Password = $KioskOpsAdminPassword
			Ensure = "Present"
			DisplayName = "KioskOps Administrative account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create a KioskOps Read Only account:
		xADUser KioskOpsReadOnlyUser
		{
            DependsOn = "[xADDomain]DomainServiceFileSetup"
			DomainName = $DomainName
			UserName = $KioskOpsReadOnlyAccount
			Password = $KioskOpsReadOnlyPassword
			Ensure = "Present"
			DisplayName = "KioskOps Read Only account"
			DomainAdministratorCredential = $DomainCredentials
		}

		# Create an AD Group for KioskOps EXEC:
# 		xADGroup KioskOpsDbExecGroup
# 		{
#             DependsOn = "[xADDomain]DomainServiceFileSetup"
# 			GroupName = "KioskOpsDbExec"
# 			Path = "CN=KioskOpsEXEC,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
# 			Ensure = "Present"
# 			Description = "KioskOps database Execute"
# 			DisplayName = "KioskOps DB EXEC"
# 			Credential = $DomainCredentials
# 			MembersToInclude = "$DomainName\$WebServerAdminAccount", "$DomainName\$AppServerServiceAccount"
# 		}

		# Create an AD Group for KioskOps Administrator:
# 		xADGroup KioskOpsDbAdminGroup
# 		{
#           DependsOn = "[xADDomain]DomainServiceFileSetup"
# 			GroupName = "KioskOpsDbAdmin"
# 			Path = "CN=KioskOpsAdmin,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
# 			Ensure = "Present"
# 			Description = "KioskOps database Administrators"
# 			DisplayName = "KioskOps DB Admins"
# 			Credential = $DomainCredentials
# 			MembersToInclude = "$DomainName\$KioskOpsAdminAccount"
# 		}

		# Create an AD Group for KioskOps ReadOnly:
# 		xADGroup KioskOpsDbReadOnlyGroup
# 		{
#           DependsOn = "[xADDomain]DomainServiceFileSetup"
# 			GroupName = "KioskOpsDbReadOnly"
# 			Path = "CN=KioskOpsReadOnly,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
# 			Ensure = "Present"
# 			Description = "KioskOps database Read Only"
# 			DisplayName = "KioskOps DB Read Only"
# 			Credential = $DomainCredentials
# 			MembersToInclude = "$DomainName\$KioskOpsReadOnlyAccount"
# 		}

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
   }
} 