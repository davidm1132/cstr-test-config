﻿configuration CreateBackupDcForest 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

        [Int]$RetryCount=10,
        [Int]$RetryIntervalSec=60
    ) 
    
	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xStorage, cDisk, PSDesiredStateConfiguration;
    [System.Management.Automation.PSCredential ]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password);

    $Interface = Get-NetAdapter | Where Name -Like "Ethernet*" | Select-Object -First 1;
    $InterfaceAlias = $($Interface.Name);

    Node localhost
    {
		# Add DNS Windows Feature:
		Script EnableDnsDiagnostics
		{
      	    SetScript =  { 
				Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false}
			DependsOn = "[WindowsFeature]DNS"
        }
	
		WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"		
        }

		WindowsFeature DnsTools
		{
			Ensure = "Present"
            Name = "RSAT-DNS-Server"
			DependsOn = "[WindowsFeature]DNS"
		}

       xDnsServerAddress DnsServerAddress 
       { 
           Address        = '127.0.0.1' 
           InterfaceAlias = $InterfaceAlias
           AddressFamily  = 'IPv4'
		   DependsOn = "[WindowsFeature]DNS"
       }

		# Make sure Disk #2 is available:

		xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

		# Assign Drive Letter F to Disk #2:
        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
			DependsOn = "[xWaitForDisk]Disk2"
        }

 		# Install Active Directory Domain Services:
       WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
			DependsOn = "[cDiskNoRestart]ADDataDisk"
        } 

		WindowsFeature ADAdminCenter 
        { 
            Ensure = "Present" 
            Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
        }
		
		WindowsFeature ADDSTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
        }  

		# Configure the Domain Service files:
        xWaitForADDomain DscForestWait 
        { 
			DependsOn = "[WindowsFeature]ADDSInstall"
            DomainName = $DomainName 
            DomainUserCredential= $DomainCredentials
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
        } 

        xADDomainController BDC 
        { 
			DependsOn = "[xWaitForADDomain]DscForestWait"
            DomainName = $DomainName 
            DomainAdministratorCredential = $DomainCredentials 
            SafemodeAdministratorPassword = $DomainCredentials
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
        }

#		Don't need to do this.  Eventually we'll
#		be forwarding to the InfoBlox:	
#		Script scriptRemoveDnsForwarding
#		{
#      	    SetScript =  { 
#			$dnsFwdRule = Get-DnsServerForwarder
#			if ($dnsFwdRule) { Remove-DnsServerForwarder -IPAddress $dnsFwdRule.IPAddress -Force }
#					Write-Verbose -Verbose "Removing DNS forwarding rule" 
#            }
#            GetScript =  { @{} }
#            TestScript = { $false}
#			DependsOn = "[xADDomainController]BDC"
#        }

        LocalConfigurationManager 
        {
       	    ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
   }
} 