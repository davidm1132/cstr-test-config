﻿configuration WebFileServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$UploadSharePath,

        [Int]$RetryCount = 10,
        [Int]$RetryIntervalSec = 30
    ) 
    
	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xSmbShare, xStorage;
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password);
   
    Node localhost
    {
        WindowsFeature ADPowershellFeature
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

		# Requires .NET Framework:
        WindowsFeature "NETFrameworkCore"
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
			DependsOn = "[xWaitforDisk]Disk2"
            DiskNumber = 2
            DriveLetter = "F"
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[WindowsFeature]ADPowershellFeature" 
        }


        File UploadFolder
        {
            DestinationPath = "F:\$($UploadSharePath.ToUpperInvariant())"
            Type = "Directory"
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
        }

        xSmbShare UploadShare
        {
            Name = $UploadSharePath
            Path = "F:\$($UploadSharePath.ToUpperInvariant())"
            FullAccess = "BUILTIN\Administrators"
            Ensure = "Present"
            DependsOn = "[File]UploadFolder"
        }
   }
} 