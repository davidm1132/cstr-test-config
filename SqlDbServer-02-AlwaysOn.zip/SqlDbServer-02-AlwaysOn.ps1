﻿configuration SqlServerAlwaysOn 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,


        [UInt32]$NumberOfDisks = 1,
        [String]$WorkloadType = "Transactional Processing",
		[Int]$TcpPort = 1433,
        [Int]$RetryCount = 10,
        [Int]$RetryIntervalSec = 20
    ) 

	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xDatabase, xNetworking, xSql, xSQLServer, xSQLps, xStorage;

    [String]$DomainNetbiosName = (Get-NetBIOSName -DomainName $DomainName);
    #[System.Management.Automation.PSCredential]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password);
    [System.Management.Automation.PSCredential]$SQLNetbiosCredentials = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SqlServerServiceCredentials.UserName)", $SqlServerServiceCredentials.Password)

    # SQL Server instance names do not allow dashes:
    [String]$SqlServerInstanceName = ($env:COMPUTERNAME).Replace('-', '_' );

    Node localhost
    {
        xSqlCreateVirtualDisk CreateVirtualDisk
        {
            DriveSize = $NumberOfDisks
            NumberOfColumns = $NumberOfDisks
            BytesPerDisk = 1099511627776
            OptimizationType = $WorkloadType
        }

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
            Name = $SqlServerServiceCredentials.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $True
            Credential = $AdminCredentials
        }

#        xADUser CreateSqlServerServiceAccount
#        {
#            DomainAdministratorCredential = $DomainCredentials
#            DomainName = $DomainName
#            UserName = $SqlServerServiceCredentials.UserName
#            Password = $SqlServerServiceCredentials
#            Ensure = "Present"
#            DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"
#        }

        xSqlLogin AddSqlServerServiceAccountToSysadminServerRole
        {
            Name = $SQLNetbiosCredentials.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $AdminCredentials
            DependsOn = "[xADUser]CreateSqlServerServiceAccount"
        }
        
        xSqlTsqlEndpoint AddSqlServerEndpoint
        {
            InstanceName = "MSSQLSERVER"
            PortNumber = $TcpPort
            SqlAdministratorCredential = $AdminCredentials
            DependsOn = "[xSqlLogin]AddSqlServerServiceAccountToSysadminServerRole"
        }

        xSQLServerStorageSettings AddSQLServerStorageSettings
        {
            InstanceName = "MSSQLSERVER"
            OptimizationType = $WorkloadType
            DependsOn = "[xSqlTsqlEndpoint]AddSqlServerEndpoint"
        }

        xSqlServer ConfigureSqlServerWithAlwaysOn
        {
            InstanceName = $SqlServerInstanceName
            SqlAdministratorCredential = $AdminCredentials
            ServiceCredential = $SQLNetbiosCredentials
            MaxDegreeOfParallelism = 1
            FilePath = "F:\DATA"
            LogPath = "F:\LOG"
            DomainAdministratorCredential = $DomainCredentials
            DependsOn = "[xSqlLogin]AddSqlServerServiceAccountToSysadminServerRole"
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }
   }
} 

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

