﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$SqlServerVersion,

		[Parameter(Mandatory)]
		[String]$KioskOpsDacpacPath,

		[Parameter(Mandatory)]
		[String]$KioskOpsLogDacpacPath
    ) 
    
    Import-DscResource -ModuleName @{ModuleName="xDatabase";ModuleVersion="1.4.0.0"};
   
    Node localhost
    {
        xDatabase KioskOpsSchema
        { 
			Credentials = $Admincreds,
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsDacpacPath
			DacPacApplicationName = "KioskOpsDatabase"
			DatabaseName = "KioskOps"
        }

        xDatabase KioskOpsLogSchema
        {
			Credentials = $Admincreds,
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsLogDacpacPath
			DacPacApplicationName = "KioskOpsLogDatabase"
			DatabaseName = "KioskOpsLog"
        }
   }
} 
