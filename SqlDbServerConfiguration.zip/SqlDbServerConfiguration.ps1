﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminUserCredentials,

        [Parameter(Mandatory)]
		[Int]$TcpPort,

		[String]$SqlFeatures = "SQLENGINE",
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30,
		[String]$SQLUserDBDir = "D:\\Data",
		[String]$SQLUserDBLogDir = "D:\\Logs",
		[String]$SQLTempDBDir = "D:\\TempDB",
		[String]$SQLTempDBLogDir = "D:\\TempDB"

    ) 
    
    Import-DscResource -ModuleName cDisk, xStorage;
   
    Node localhost
    {
        # Set DCM Settings for each Node 
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true 
        } 

   }
} 
