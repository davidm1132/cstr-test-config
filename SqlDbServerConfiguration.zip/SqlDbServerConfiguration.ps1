﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourcePath,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourceFolder,

        [Parameter(Mandatory)]
        [String]$SqlServerInstanceName,

        [Parameter(Mandatory)]
        [String]$SqlServerCollation,

        [Parameter(Mandatory)]
        [String]$SQLSysAdminAccounts,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlAgentServiceCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerVersion,

        [Parameter(Mandatory)]
        [String]$KioskOpsDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsCollation,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogCollation,

        [Parameter(Mandatory)]
		[Int]$TcpPort,

		[String]$SqlFeatures = "SQLENGINE",
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30,
		[String]$SQLUserDBDir = "H:\Data",
		[String]$SQLUserDBLogDir = "H:\Logs",
		[String]$SQLTempDBDir = "H:\TempDB",
		[String]$SQLTempDBLogDir = "H:\TempDB"
    ) 
    
    Import-DscResource -ModuleName cDisk, @{ModuleName="xDatabase";ModuleVersion="1.4.0.0"}, @{ModuleName="xNetworking";ModuleVersion="2.8.0.0"}, @{ModuleName="xSQLServer";ModuleVersion="1.5.0.0"}, @{ModuleName="xStorage";ModuleVersion="2.5.0.0"};
   
    Node localhost
    {
        # Set DCM Settings for each Node 
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true 
            ConfigurationMode = "ApplyOnly" 
        } 


		# Requires .NET Framework:
        WindowsFeature "NETFrameworkCore"
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
        }

        xWaitforDisk "Disk2"
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart "DriveE"
        {
            DependsOn = @("[xWaitforDisk]Disk2")
            DiskNumber = 2
            DriveLetter = "E"
        }

        xWaitforDisk "Disk3"
        {
            DependsOn = @("[cDiskNoRestart]DriveE")
            DiskNumber = 3
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        cDiskNoRestart "DriveH"
        {
            DependsOn = @("[xWaitforDisk]Disk3")
            DiskNumber = 3
            DriveLetter = "H"
        }

		# Install SQL Server; SecurityMode = "SQL"
		# means use "Mixed Mode":
        xSqlServerSetup "RDBMS"
        {
            DependsOn = @("[cDiskNoRestart]DriveE")
            SourcePath = $SqlInstallSourcePath
            SourceFolder = $SqlInstallSourceFolder
            InstanceName = $SqlServerInstanceName
            Features = $SqlFeatures
            SetupCredential = $AdminCredentials
            SQLCollation = $SqlServerCollation
			SecurityMode = "SQL"
            SQLSysAdminAccounts = $SQLSysAdminAccounts
			SQLUserDBDir = $SQLUserDBDir
			SQLUserDBLogDir = $SQLUserDBLogDir
			SQLTempDBDir = $SQLTempDBDir
			SQLTempDBLogDir = $SQLTempDBLogDir
            SQLSvcAccount = $SqlServerServiceCredentials
            AgtSvcAccount = $SqlAgentServiceCredentials
        }

		# Configure firewall settings:
        xSqlServerFirewall "DbFirewall"
        {
            DependsOn = @("[xSqlServerSetup]RDBMS")
            SourcePath = $SqlInstallSourcePath
            SourceFolder = $SqlInstallSourceFolder
            Features = $SqlFeatures
            InstanceName = $SqlServerInstanceName
        }


		# Create KioskOps database schema:
        xDatabase "KioskOpsDb"
        { 
            DependsOn = @("[xSqlServerSetup]RDBMS")
			Credentials = $AdminCredentials
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsDacpacPath
			DacPacApplicationName = "KioskOpsDb"
			DatabaseName = "KioskOps"
            Ensure = "Present"
        }

		# Create KioskOpsLog database schema:
        xDatabase "KioskOpsLogDb"
        {
            DependsOn = @("[xDatabase]KioskOpsDb")
			Credentials = $AdminCredentials
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsLogDacpacPath
			DacPacApplicationName = "KioskOpsLogDb"
			DatabaseName = "KioskOpsLog"
            Ensure = "Present"
        }

        # This will enable TCP/IP protocol, set custom static port,
		# and will restart the sql service
        xSQLServerNetwork "DbNetwork"
        {
            DependsOn = @("[xDatabase]KioskOpsLogDb")
            InstanceName = $SqlServerInstanceName
            ProtocolName = "tcp"
            IsEnabled = $true
            TCPPort = $TcpPort
            RestartService = $true 
        }        
   }
} 
