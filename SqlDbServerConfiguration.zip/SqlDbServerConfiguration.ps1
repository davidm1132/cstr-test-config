﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminUserCredentials,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourcePath,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourceFolder,

        [Parameter(Mandatory)]
        [String]$InstanceName,

        [Parameter(Mandatory)]
        [String]$ProductId,

        [Parameter(Mandatory)]
        [String]$SqlServerCollation,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLSysAdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlAgentServiceCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerVersion,

        [Parameter(Mandatory)]
        [String]$KioskOpsDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsCollation,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogCollation,

        [Parameter(Mandatory)]
		[Int]$TcpPort,

		[String]$SqlFeatures = "SQLENGINE",
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30,
		[String]$SQLUserDBDir = "E:\\Data",
		[String]$SQLUserDBLogDir = "E:\\Logs",
		[String]$SQLTempDBDir = "E:\\TempDB",
		[String]$SQLTempDBLogDir = "E:\\TempDB"

    ) 
    
    Import-DscResource -ModuleName cDisk, @{ModuleName="xStorage";ModuleVersion="2.5.0.0"}, @{ModuleName="xNetworking";ModuleVersion="2.8.0.0"}, @{ModuleName="xSQLServer";ModuleVersion="1.5.0.0"}, @{ModuleName="xDatabase";ModuleVersion="1.4.0.0"};
   
    Node localhost
    {
        # Set DCM Settings for each Node 
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true 
            ConfigurationMode = "ApplyOnly" 
        } 

		# Requires .NET Framework:
        WindowsFeature "NET-Framework-Core"
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart ADDataDiskD
        {
            DiskNumber = 2
            DriveLetter = "D"
        }

        xWaitforDisk Disk3
        {
             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart ADDataDiskE
        {
            DiskNumber = 3
            DriveLetter = "E"
        }

		# Install SQL Server:
        xSqlServerSetup "RDBMS"
        {
            DependsOn = @("[WindowsFeature]NET-Framework-Core"), @("[cDiskNoRestart]ADDataDiskD")
            SourcePath = $SqlInstallSourcePath
            SourceFolder = $SqlInstallSourceFolder
            InstanceName = $InstanceName
            Features = $SqlFeatures
            SetupCredential = $AdminUserCredentials
            SQLCollation = $SqlServerCollation
            SQLSysAdminAccounts = $SQLSysAdminCredentials
			SQLUserDBDir = $SQLUserDBDir
			SQLUserDBLogDir = $SQLUserDBLogDir
			SQLTempDBDir = $SQLTempDBDir
			SQLTempDBLogDir = $SQLTempDBLogDir
            SQLSvcAccount = $SqlServerServiceCredentials
            AgtSvcAccount = $SqlAgentServiceCredentials
        }

		# Configure firewall settings:
        xSqlServerFirewall "RDBMS"
        {
            DependsOn = @("[xSqlServerSetup]RDBMS")
            SourcePath = $SqlInstallSourcePath
            SourceFolder = $SqlInstallSourceFolder
            InstanceName = $InstanceName
            Features = $SqlFeatures
        }

		# Create KioskOps database schema:
        xDatabase KioskOpsSchema
        { 
            DependsOn = @("[xSqlServerSetup]RDBMS"), @("[cDiskNoRestart]ADDataDiskE")
			Credentials = $SQLSysAdminCredentials,
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsDacpacPath
			DacPacApplicationName = "KioskOps-Database"
			DatabaseName = "KioskOps"
        }

		# Create KioskOpsLog database schema:
        xDatabase KioskOpsLogSchema
        {
            DependsOn = @("[xSqlServerSetup]RDBMS"), @("[cDiskNoRestart]ADDataDiskE")
			Credentials = $SQLSysAdminCredentials,
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsLogDacpacPath
			DacPacApplicationName = "KioskOpsLog-Database"
			DatabaseName = "KioskOpsLog"
        }

        # This will enable TCP/IP protocol, set custom static port,
		# and will restart the sql service
        xSQLServerNetwork "RDBMS"
        {
            DependsOn = @("[xDatabase]KioskOpsSchema"), @("[xDatabase]KioskOpsLogSchema")
            InstanceName = $InstanceName
            ProtocolName = "tcp"
            IsEnabled = $true
            TCPPort = $TcpPort
            RestartService = $true 
        }        
   }
} 
