﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminUserCredentials,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourcePath,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourceFolder,

        [Parameter(Mandatory)]
        [String]$InstanceName,

        [Parameter(Mandatory)]
        [String]$ProductId,

        [Parameter(Mandatory)]
        [String]$SqlServerCollation,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLSysAdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlAgentServiceCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerVersion,

        [Parameter(Mandatory)]
        [String]$KioskOpsDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsCollation,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogCollation,

        [Parameter(Mandatory)]
		[Int]$TcpPort,

		[String]$SqlFeatures = "SQLENGINE",
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30,
		[String]$SQLUserDBDir = "E:\\Data",
		[String]$SQLUserDBLogDir = "E:\\Logs",
		[String]$SQLTempDBDir = "E:\\TempDB",
		[String]$SQLTempDBLogDir = "E:\\TempDB"

    ) 
    
    Import-DscResource -ModuleName @{ModuleName="cDisk"}, @{ModuleName="xStorage";ModuleVersion="2.5.0.0"}, @{ModuleName="xNetworking";ModuleVersion="2.8.0.0"}, @{ModuleName="xSQLServer";ModuleVersion="1.5.0.0"}, @{ModuleName="xDatabase";ModuleVersion="1.4.0.0"};
   
    Node localhost
    {
        # Set DCM Settings for each Node 
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true 
            ConfigurationMode = "ApplyOnly" 
        } 

		# Requires .NET Framework:
        WindowsFeature "NETFrameworkCore"
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
        }

        xWaitforDisk "Disk2"
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart "DriveD"
        {
            DiskNumber = 2
            DriveLetter = "D"
        }

        xWaitforDisk "Disk3"
        {
             DiskNumber = 3
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart "DriveE"
        {
            DiskNumber = 3
            DriveLetter = "E"
        }

		# Install SQL Server:
        xSqlServerSetup "RDBMS"
        {
            DependsOn = @("[WindowsFeature]NETFrameworkCore"), @("[cDiskNoRestart]DriveD"), @("[cDiskNoRestart]DriveE")
            SourcePath = $SqlInstallSourcePath
            SourceFolder = $SqlInstallSourceFolder
            InstanceName = $InstanceName
            Features = $SqlFeatures
            SetupCredential = $AdminUserCredentials
            SQLCollation = $SqlServerCollation
            SQLSysAdminAccounts = $SQLSysAdminCredentials
			SQLUserDBDir = $SQLUserDBDir
			SQLUserDBLogDir = $SQLUserDBLogDir
			SQLTempDBDir = $SQLTempDBDir
			SQLTempDBLogDir = $SQLTempDBLogDir
            SQLSvcAccount = $SqlServerServiceCredentials
            AgtSvcAccount = $SqlAgentServiceCredentials
        }

		# Configure firewall settings:
        xSqlServerFirewall "DbFirewall"
        {
            DependsOn = @("[xSqlServerSetup]RDBMS")
            SourcePath = $SqlInstallSourcePath
            SourceFolder = $SqlInstallSourceFolder
            InstanceName = $InstanceName
            Features = $SqlFeatures
        }

		# Create KioskOps database schema:
        xDatabase "KioskOpsDb"
        { 
            DependsOn = @("[xSqlServerSetup]RDBMS")
			Credentials = $SQLSysAdminCredentials
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsDacpacPath
			DacPacApplicationName = "KioskOpsDb"
			DatabaseName = "KioskOps"
        }

		# Create KioskOpsLog database schema:
        xDatabase "LogDb"
        {
            DependsOn = @("[xSqlServerSetup]RDBMS")
			Credentials = $SQLSysAdminCredentials
			SqlServer = $env:COMPUTERNAME
			SqlServerVersion = $SqlServerVersion
			DacPacPath = $KioskOpsLogDacpacPath
			DacPacApplicationName = "KioskOpsLogDb"
			DatabaseName = "KioskOpsLog"
        }

        # This will enable TCP/IP protocol, set custom static port,
		# and will restart the sql service
        xSQLServerNetwork "DbNetwork"
        {
            DependsOn = @("[xDatabase]KioskOpsDb"), @("[xDatabase]LogDb")
            InstanceName = $InstanceName
            ProtocolName = "tcp"
            IsEnabled = $true
            TCPPort = $TcpPort
            RestartService = $true 
        }        
   }
} 
