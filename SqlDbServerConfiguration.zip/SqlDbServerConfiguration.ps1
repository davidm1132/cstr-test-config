﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

        [Parameter(Mandatory)]
        [String]$InstallPath,

        [Parameter(Mandatory)]
        [String]$InstallFolder,

        [Parameter(Mandatory)]
        [String]$SqlServerInstanceName,

        [Parameter(Mandatory)]
        [String]$SqlServerProductId,

        [Parameter(Mandatory)]
        [String]$SqlServerCollation,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLSysAdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlAgentServiceCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerVersion,

        [Parameter(Mandatory)]
        [String]$KioskOpsDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsCollation,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogCollation,

        [Parameter(Mandatory)]
		[Int]$TcpPort,

		[String]$SqlFeatures = "SQLENGINE",
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30,
		[String]$SQLUserDBDir = "E:\\Data",
		[String]$SQLUserDBLogDir = "E:\\Logs",
		[String]$SQLTempDBDir = "E:\\TempDB",
		[String]$SQLTempDBLogDir = "E:\\TempDB"
    ) 
    
    Import-DscResource -ModuleName cDisk, xStorage;
   
    Node localhost
    {
        # Set DCM Settings for each Node 
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true 
            ConfigurationMode = "ApplyOnly" 
        } 

   }
} 
