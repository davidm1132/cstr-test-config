﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

        [Parameter(Mandatory)]
        [String]$InstallPath,

        [Parameter(Mandatory)]
        [String]$InstallFolder,

        [Parameter(Mandatory)]
		[Int]$TcpPort,

		[String]$Features = "SQLENGINE",
        [Int]$RetryCount = 20,
        [Int]$RetrySeconds = 30,
		[String]$DBDir = "D:\\Data",
		[String]$DBLogDir = "D:\\Logs",
		[String]$TempDir = "D:\\TempDB",
		[String]$TempLogDir = "D:\\TempDB"

    ) 
    
    Import-DscResource -ModuleName cDisk, xStorage;
   
    Node localhost
    {
        # Set DCM Settings for each Node 
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true 
        } 

   }
} 
