﻿configuration SqlDbServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminUserCredentials,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourcePath,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourceFolder,

        [Parameter(Mandatory)]
        [String]$InstanceName,

        [Parameter(Mandatory)]
        [String]$ProductId,

        [Parameter(Mandatory)]
        [String]$SqlServerCollation,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLSysAdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlAgentServiceCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerVersion,

        [Parameter(Mandatory)]
        [String]$KioskOpsDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsCollation,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogDacpacPath,

        [Parameter(Mandatory)]
        [String]$KioskOpsLogCollation,

        [Parameter(Mandatory)]
		[Int]$TcpPort,

		[String]$SqlFeatures = "SQLENGINE",
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30,
		[String]$SQLUserDBDir = "D:\\Data",
		[String]$SQLUserDBLogDir = "D:\\Logs",
		[String]$SQLTempDBDir = "D:\\TempDB",
		[String]$SQLTempDBLogDir = "D:\\TempDB"

    ) 
    
    Import-DscResource -ModuleName cDisk, xStorage;
   
    Node localhost
    {
        # Set DCM Settings for each Node 
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true 
        } 

   }
} 
