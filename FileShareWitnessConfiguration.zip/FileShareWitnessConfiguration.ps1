#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration CreateFileShareWitness
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,

        [Parameter(Mandatory)]
        [String]$FswSharePath,

        [Int]$RetryCount = 10,
        [Int]$RetryIntervalSec = 30
    )

	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xSmbShare, xStorage;
    
    Node localhost
    {
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FailoverClusterTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-Clustering-Mgmt"
            DependsOn = "[WindowsFeature]FC"
        } 

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]FC"
        }

        WindowsFeature FCCmd
        {
            Name = "RSAT-Clustering-CmdInterface"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]FC"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
			DependsOn = "[xWaitforDisk]Disk2"
            DiskNumber = 2
            DriveLetter = "F"
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password)	
            DependsOn = "[WindowsFeature]ADPS"
        }

        File FSWFolder
        {
            DestinationPath = "F:\$($FswSharePath.ToUpperInvariant())"
            Type = "Directory"
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
        }

        xSmbShare FSWShare
        {
            Name = $FswSharePath.ToUpperInvariant()
            Path = "F:\$($FswSharePath.ToUpperInvariant())"
            FullAccess = "BUILTIN\Administrators", "BUILTIN\Domain Admins", "${DomainName}\$($SqlServerServiceCredentials.UserName)"
            Ensure = "Present"
            DependsOn = "[File]FSWFolder"
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }
    }  
}
