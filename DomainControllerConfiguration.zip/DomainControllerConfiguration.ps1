﻿configuration CreateActiveDirectoryForest 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$DbAdminUserName,

        [Parameter(Mandatory)]
        [String]$SysAdminUserName,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking;
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password);

    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }       
        
        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = "127.0.0.1" 
            InterfaceAlias = "Ethernet"
            AddressFamily  = "IPv4"
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
			FSLabel = "CSTR"
        }

        WindowsFeature ADDomainServiceInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }  

        xADDomain DomainServiceFiles 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
        }

		xADUser AdAzureDbAdminUser
		{
			DomainName = $DomainName
			UserName = $DbAdminUserName
			Password = "Cstr.425"
			Ensure = "Present"
			Enabled = $true
			PasswordNeverExpires = $false
			Description = "Azure SQL Database Admin User"
		}

		xADUser AdSysAdminUser
		{
			DomainName = $DomainName
			UserName = $SysAdminUserName
			Password = "Cstr.425"
			Ensure = "Present"
			Enabled = $true
			PasswordNeverExpires = $false
			Description = "System Admin User"
		}


		xADGroup AdAzureDbAdminsGroup
		{
			GroupName = "AzureDbAdminsGroup"
			Category = "Security"
			GroupScope = "DomainLocal"
			Description = "Azure SQL database Administrators Group"
			Ensure = "Present"
		}

		xADGroup AdWebServicesGroup
		{
			GroupName = "WebServicesGroup"
			Category = "Security"
			GroupScope = "DomainLocal"
			Description = "Web Services  Group"
			Ensure = "Present"
		}

		xADGroup AdWindowsServicesGroup
		{
			GroupName = "WindowsServicesGroup"
			Category = "Security"
			GroupScope = "DomainLocal"
			Description = "Windows Services  Group"
			Ensure = "Present"
		}

		xADGroup AdSystemAdminsGroup
		{
			GroupName = "SystemAdminsGroup"
			Category = "Security"
			GroupScope = "DomainLocal"
			Description = "System Admins  Group"
			Ensure = "Present"
		}

   }
} 