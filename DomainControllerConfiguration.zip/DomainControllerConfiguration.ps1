﻿configuration CreateActiveDirectoryForest 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerServiceAccount,

        [Parameter(Mandatory)]
		[String]$SqlServerServicePassword,

        [Parameter(Mandatory)]
        [String]$SqlAgentServiceAccount,

        [Parameter(Mandatory)]
        [String]$SqlAgentServicePassword,

        [Parameter(Mandatory)]
        [String]$SqlServerAdminAccount,

        [Parameter(Mandatory)]
        [String]$SqlServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$WebServiceAppPoolAccount,

        [Parameter(Mandatory)]
        [String]$WebServiceAppPoolPassword,

        [Parameter(Mandatory)]
        [String]$WebServerAdminAccount,

        [Parameter(Mandatory)]
        [String]$WebServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$AppServerServiceAccount,

        [Parameter(Mandatory)]
        [String]$AppServerServicePassword,

        [Parameter(Mandatory)]
        [String]$AppServerAdminAccount,

        [Parameter(Mandatory)]
        [String]$AppServerAdminPassword,

        [Parameter(Mandatory)]
        [String]$KioskOpsAdminAccount,

        [Parameter(Mandatory)]
        [String]$KioskOpsAdminPassword,

        [Parameter(Mandatory)]
        [String]$KioskOpsReadOnlyAccount,

        [Parameter(Mandatory)]
        [String]$KioskOpsReadOnlyPassword,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, cDisk;
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password);

    Node localhost
    {
        LocalConfigurationManager 
		{
            RebootNodeIfNeeded = $true
        }       
        
		# Add DNS Windows Feature:
        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = "127.0.0.1" 
            InterfaceAlias = "Ethernet"
            AddressFamily  = "IPv4"
        }

		# Make sure Disk #2 is available:
        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

		# Assign Drive Letter F to Disk #2:
        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
        }

		# Install Active Directory Domain Services:
        WindowsFeature ADDomainServiceInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }  

		# Configure the Domain Service files:
        xADDomain DomainServiceFileSetup 
        {
            DependsOn = @("[cDiskNoRestart]ADDataDisk")
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
        }

		# Create a SQL Server Windows Service user account:
		xADUser SqlServerServiceUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $SqlServerServiceAccount
			Password = $SqlServerServicePassword
			Ensure = "Present"
			DisplayName = "SQL Server Service account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create a SQL Agent Windows Service user account:
		xADUser SqlAgentServiceUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $SqlAgentServiceAccount
			Password = $SqlAgentServicePassword
			Ensure = "Present"
			DisplayName = "SQL Agent Service account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create a SQL Server Administrative user account:
		xADUser SqlServerAdminUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $SqlServerAdminAccount
			Password = $SqlServerAdminPassword
			Ensure = "Present"
			DisplayName = "SQL Server Admin account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create a Web Service App Pool account:
		xADUser WebServiceAppPoolUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $WebServiceAppPoolAccount
			Password = $WebServiceAppPoolPassword
			Ensure = "Present"
			DisplayName = "Web Service App Pool account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create a Web Server Admin account:
		xADUser WebServerAdminUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $WebServerAdminAccount
			Password = $WebServerAdminPassword
			Ensure = "Present"
			DisplayName = "Web Server Admin account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create an Application Service account:
		xADUser AppServerServiceUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $AppServerServiceAccount
			Password = $AppServerServicePassword
			Ensure = "Present"
			DisplayName = "Application Server service account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create a App Server Admin account:
		xADUser AppServerAdminUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $AppServerAdminAccount
			Password = $AppServerAdminPassword
			Ensure = "Present"
			DisplayName = "Application Server Admin account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create a KioskOps Administrative account:
		xADUser KioskOpsAdminUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $KioskOpsAdminAccount
			Password = $KioskOpsAdminPassword
			Ensure = "Present"
			DisplayName = "KioskOps Administrative account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create a KioskOps Read Only account:
		xADUser KioskOpsReadOnlyUser
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			DomainName = $DomainName
			UserName = $KioskOpsReadOnlyAccount
			Password = $KioskOpsReadOnlyPassword
			Ensure = "Present"
			DisplayName = "KioskOps Read Only account"
			DomainAdministratorCredential = $DomainCreds
		}

		# Create an AD Group for KioskOps EXEC:
		xADGroup KioskOpsDbExecGroup
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			GroupName = "KioskOpsDbExec"
			Path = "CN=KioskOpsEXEC,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
			Ensure = "Present"
			Description = "KioskOps database Execute"
			DisplayName = "KioskOps DB EXEC"
			DomainAdministratorCredential = $DomainCreds
			MembersToInclude = "$WebServerAdminAccount; $AppServerServiceAccount"
		}

		# Create an AD Group for KioskOps Administrator:
		xADGroup KioskOpsDbAdminGroup
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			GroupName = "KioskOpsDbAdmin"
			Path = "CN=KioskOpsAdmin,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
			Ensure = "Present"
			Description = "KioskOps database Administrators"
			DisplayName = "KioskOps DB Admins"
			MembersToInclude = "$KioskOpsAdminAccount"
		}

		# Create an AD Group for KioskOps ReadOnly:
		xADGroup KioskOpsDbReadOnlyGroup
		{
            DependsOn = @("[xADDomain]DomainServiceFileSetup")
			GroupName = "KioskOpsDbReadOnly"
			Path = "CN=KioskOpsReadOnly,OU=KioskOpsDB,DC=OUTERWALL,DC=COM"
			Ensure = "Present"
			Description = "KioskOps database Read Only"
			DisplayName = "KioskOps DB Read Only"
			MembersToInclude = "$KioskOpsReadOnlyAccount"
		}
   }
} 