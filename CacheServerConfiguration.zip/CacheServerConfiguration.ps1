﻿configuration CacheServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30
    ) 
    
	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement;
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password);
   
    Node localhost
    {
        WindowsFeature ADPowershellFeature
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

		# Requires .NET Framework:
        WindowsFeature NETFrameworkCore
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
        }

        xWaitForADDomain WaitForDomain 
        { 
            DependsOn = "[WindowsFeature]ADPowershellFeature" 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
        }

        xComputer DomainJoin
        {
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
   }
} 
