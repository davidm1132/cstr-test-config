﻿configuration WebServerConfiguration 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30
    ) 
    
	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName @{ModuleName="xActiveDirectory";ModuleVersion="2.10.0.0"}, @{ModuleName="xComputerManagement";ModuleVersion="1.5.0.0"};
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password);
   
    Node localhost
    {
        WindowsFeature ADPowershellFeature
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        WindowsFeature WebServerFeature
        {
            Name = "Web-Server"
            Ensure = "Present"
			IncludeAllSubFeature = $true
        } 

        xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]ADPowershellFeature" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }
   }
} 