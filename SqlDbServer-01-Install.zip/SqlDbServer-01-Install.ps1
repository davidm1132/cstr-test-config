﻿configuration SqlDbServerInstall 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCredentials,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourcePath,

        [Parameter(Mandatory)]
        [String]$SqlInstallSourceFolder,

        [Parameter(Mandatory)]
        [String]$SqlServerCollation,

        [Parameter(Mandatory)]
        [String]$SQLSysAdminAccounts,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlSysAdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlServerServiceCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SqlAgentServiceCredentials,

        [Parameter(Mandatory)]
        [String]$SqlServerVersion,

        [Parameter(Mandatory)]
		[Int]$TcpPort = 1433,

        [String]$WitnessSharePath = "Witness",
		[String]$SqlFeatures = "SQLENGINE,SSMS,ADV_SSMS",
        [Int]$RetryCount = 10,
        [Int]$RetryIntervalSec = 20,
		[String]$SQLUserDBDir = "H:\Data",
		[String]$SQLUserDBLogDir = "H:\Logs",
		[String]$SQLTempDBDir = "H:\TempDB",
		[String]$SQLTempDBLogDir = "H:\TempDB"
    ) 

	# To ensure that DSC can find the modules it downloaded:    
	$env:PSModulePath = $env:PSModulePath + ";C:\Program Files\WindowsPowerShell\Modules";

    Import-DscResource -ModuleName cDisk, xActiveDirectory, xComputerManagement, xNetworking, xSmbShare, xSQLServer, xStorage;
    [System.Management.Automation.PSCredential]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password);

    [String]$TcpPortString = $TcpPort.ToString();

    # SQL Server instance names do not allow dashes:
    [String]$SqlServerInstanceName = ($env:COMPUTERNAME).Replace('-', '_' );

    Node localhost
    {
        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature FailoverClusterTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-Clustering-Mgmt"
            DependsOn = "[WindowsFeature]FC"
        } 

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]FC"
        }

        WindowsFeature FCCmd
        {
            Name = "RSAT-Clustering-CmdInterface"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]FC"
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain WaitForDomain
        { 
            DomainName = $DomainName 
            DomainUserCredential= $AdminCredentials
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]ADPS" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCredentials
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

		# Requires .NET Framework:
        WindowsFeature NETFrameworkCore
        {
            Ensure = "Present"
            Name = "NET-Framework-Core"
        }

		# Mount the drives:
        xWaitforDisk Disk2
        {
            DependsOn = "[xComputer]DomainJoin"
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        cDiskNoRestart DriveE
        {
            DependsOn = "[xWaitforDisk]Disk2"
            DiskNumber = 2
            DriveLetter = "E"
        }

        xWaitforDisk Disk3
        {
            DependsOn = "[cDiskNoRestart]DriveE"
            DiskNumber = 3
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        cDiskNoRestart DriveH
        {
            DependsOn = "[xWaitforDisk]Disk3"
            DiskNumber = 3
            DriveLetter = "H"
        }

        xFirewall DatabaseEngineFirewallRule
        {
            Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
            Group = "SQL Server"
            Ensure = "Present"
            Enabled = "True"
            Direction = "Inbound"
            LocalPort = ($TcpPortString)
            Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
        }

        xFirewall DatabaseMirroringFirewallRule
        {
            Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
            Group = "SQL Server"
            Ensure = "Present"
            Enabled = "True"
            Direction = "Inbound"
            LocalPort = ("5022")
            Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
        }

        xFirewall ListenerFirewallRule
        {
            Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
            Group = "SQL Server"
            Ensure = "Present"
            Enabled = "True"
            Direction = "Inbound"
            LocalPort = ("59999")
            Protocol = "TCP"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
        }


        File FSWFolder
        {
            DestinationPath = "H:\$($WitnessSharePath.ToUpperInvariant())"
            Type = "Directory"
            Ensure = "Present"
            DependsOn = "[cDiskNoRestart]DriveH"
        }

        xSmbShare FSWShare
        {
            Name = $WitnessSharePath.ToUpperInvariant()
            Path = "H:\$($WitnessSharePath.ToUpperInvariant())"
            FullAccess = "BUILTIN\Administrators"
            Ensure = "Present"
            DependsOn = "[File]FSWFolder"
        }

		# Install SQL Server; SecurityMode = "SQL"
		# means use "Mixed Mode":
        xSqlServerSetup RDBMS
        {
            DependsOn = "[cDiskNoRestart]DriveE"
            SourcePath = $SqlInstallSourcePath
            SourceFolder = $SqlInstallSourceFolder
            InstanceName = $SqlServerInstanceName
            Features = $SqlFeatures
            SetupCredential = $AdminCredentials
            SQLCollation = $SqlServerCollation
			SAPwd = $SqlSysAdminCredentials
			SecurityMode = "SQL"
            SQLSysAdminAccounts = $SQLSysAdminAccounts
			SQLUserDBDir = $SQLUserDBDir
			SQLUserDBLogDir = $SQLUserDBLogDir
			SQLTempDBDir = $SQLTempDBDir
			SQLTempDBLogDir = $SQLTempDBLogDir
            SQLSvcAccount = $SqlServerServiceCredentials
            AgtSvcAccount = $SqlAgentServiceCredentials
        }

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

   }
} 
